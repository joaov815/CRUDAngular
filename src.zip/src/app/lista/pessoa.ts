export class Pessoa{
    codigo: number;
    nome: string;
    idade: number;
    sexo: string;
    rg: number;
}